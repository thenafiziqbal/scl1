// services/firebase.ts

export const firebaseConfig = {
  apiKey: "AIzaSyBtedt3DdNf3cX99-tOsqdnvMhDGFphNsI",
  authDomain: "schoolmanazmentbynfz.firebaseapp.com",
  databaseURL: "https://schoolmanazmentbynfz-default-rtdb.firebaseio.com",
  projectId: "schoolmanazmentbynfz",
  storageBucket: "schoolmanazmentbynfz.appspot.com",
  messagingSenderId: "12002840470",
  appId: "1:12002840470:web:cfaaf4db50c030067017b7",
  measurementId: "G-TQEDT28GR2"
};
