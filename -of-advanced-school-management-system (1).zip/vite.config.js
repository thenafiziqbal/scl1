import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  // গুরুত্বপূর্ণ: 'advanced-school-management-system' এর জায়গায় আপনার GitHub রিপোজিটরির নাম দিন।
  // যেমন: '/my-school-app/'
  base: '/advanced-school-management-system/',
});
