
import React from 'react';
import { useApp } from '../context/AppContext';
import { Schedule } from '../types';

const TeacherDashboard: React.FC = () => {
    const { user, schedules, invigilatorRosters, mainExams, rooms } = useApp();
    const days = ["শনিবার", "রবিবার", "সোমবার", "মঙ্গলবার", "বুধবার", "বৃহস্পতিবার"];
    const dayMap = [1, 2, 3, 4, 5, 6, 0]; // JS Day -> App Day (Sat=0, Sun=1) mapping
    const todayIndex = dayMap[new Date().getDay()];
    const todayDate = new Date();
    todayDate.setHours(0,0,0,0);

    if (!user) return null;

    // FIX: Add explicit type for `s` to resolve property access errors.
    const mySchedules = Object.values(schedules).filter((s: Schedule) => s.teacherId === user.uid);
    const todaysClasses = mySchedules.filter((s: Schedule) => parseInt(s.day, 10) === todayIndex).sort((a: Schedule, b: Schedule) => a.startTime.localeCompare(b.startTime));
    
    const myDuties = Object.entries(invigilatorRosters)
        .flatMap(([examId, dates]) => 
            Object.entries(dates).flatMap(([date, roster]) => 
                Object.entries(roster)
                    .filter(([, teacherId]) => teacherId === user.uid)
                    .map(([roomId]) => ({
                        examName: mainExams[examId]?.name || 'Unknown Exam',
                        date: date,
                        roomName: rooms[roomId]?.name || 'Unknown Room'
                    }))
            )
        )
        .filter(duty => new Date(duty.date) >= todayDate)
        .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());


    return (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-8">
                <div className="bg-white p-6 rounded-xl shadow-lg">
                    <h2 className="text-xl font-bold text-primary mb-4">আজকের ক্লাস</h2>
                    {todaysClasses.length > 0 ? (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {todaysClasses.map((s: Schedule) => (
                                <div key={s.id} className="bg-light p-4 rounded-lg border-l-4 border-secondary">
                                    <h4 className="font-bold text-lg">{s.className} ({s.section})</h4>
                                    <p><strong>বিষয়:</strong> {s.subject}</p>
                                    <p><strong>সময়:</strong> {s.startTime} - {s.endTime}</p>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <p>আজ আপনার কোনো ক্লাস নেই।</p>
                    )}
                </div>

                <div className="bg-white p-6 rounded-xl shadow-lg">
                    <h2 className="text-xl font-bold text-primary mb-4">আমার সাপ্তাহিক রুটিন</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                        {days.map((day, index) => (
                            <div key={day} className="bg-light p-4 rounded-lg">
                                <h3 className="font-bold text-center border-b-2 border-secondary pb-2 mb-2">{day}</h3>
                                <div className="space-y-2">
                                    {mySchedules.filter((s: Schedule) => parseInt(s.day, 10) === index).sort((a:Schedule,b:Schedule) => a.startTime.localeCompare(b.startTime)).map((s: Schedule) => (
                                        <div key={s.id} className="bg-white p-3 rounded shadow-sm text-sm">
                                            <p className="font-semibold">{s.className} ({s.section})</p>
                                            <p>বিষয়: {s.subject}</p>
                                            <p>সময়: {s.startTime} - {s.endTime}</p>
                                        </div>
                                    ))}
                                    {mySchedules.filter((s: Schedule) => parseInt(s.day, 10) === index).length === 0 && <p className="text-xs text-center text-gray-500">কোনো ক্লাস নেই</p>}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
            <div className="bg-white p-6 rounded-xl shadow-lg">
                 <h2 className="text-xl font-bold text-primary mb-4">আসন্ন ডিউটি</h2>
                 {myDuties.length > 0 ? (
                    <div className="space-y-3">
                        {myDuties.map((duty, index) => (
                            <div key={index} className="bg-light p-4 rounded-lg border-l-4 border-yellow-500">
                                <p className="font-bold text-accent">{duty.examName}</p>
                                <p><strong>তারিখ:</strong> {duty.date}</p>
                                <p><strong>রুম:</strong> {duty.roomName}</p>
                            </div>
                        ))}
                    </div>
                 ) : (
                    <p className="text-gray-500">আপনার কোনো আসন্ন ডিউটি নেই।</p>
                 )}
            </div>
        </div>
    );
};

export default TeacherDashboard;
